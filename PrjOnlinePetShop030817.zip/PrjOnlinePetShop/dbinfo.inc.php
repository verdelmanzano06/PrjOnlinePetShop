<?php 
	define("ORA_CON_UN", "phpuser");
	define("ORA_CON_PW", "welcome");
	define("ORA_CON_DB", "//localhost/XE");
 ?>