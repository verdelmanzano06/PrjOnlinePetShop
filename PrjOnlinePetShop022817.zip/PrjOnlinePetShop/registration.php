<!DOCTYPE html>
<html>
<head>
	<title>MnM Online Petshop - Best place to meet our best friends.</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<img class="logo" src="media/header.png"/>
		<form method="post" class="formSearch">
			<input type="search" name="search-text" placeholder="Search a pet"/>
			<input type="button" name="search-button" value="Search"/>
		</form>
	</header>
		<nav>
			<ul>
				<li><a href="#">HOME</a></li>
				<li><a href="#">DOGS</a></li>
				<li><a href="#">CATS</a></li>
				<li><a href="#">REPTILES</a></li>
				<li><a href="#">ALL PETS</a></li>
				<li><a href="#">MY ACCOUNT</a></li>
				<li><a href="#">ORDERS</a></li>
				<li><a href="#">ABOUT US</a></li>
			</ul>

		</nav>
	<div id="container">
		<div id="sidebar">
			<div class="category-head">
				<h2>ALL PETS</h2>
			</div>
			<div class="category-head">
				<h2>DOGS</h2>
			</div>
			<div class="category-head">
				<h2>CATS</h2>
			</div>
			<div class="category-head">
				<h2>REPTILES</h2>
			</div>
		</div>
		<div id="content">
			<div class="register-box">
				<h2>Sign up - New Account</h2>
				<form method="post">
					<label>Username: </label><br/>
						<input type="text" name="username"/><br/>
					<label>Password: </label><br/>
						<input type="password" name="password"/><br/>
					<label>Confirm password: </label><br/>
						<input type="password" name="cpassword"/><br/>
					<label>E-mail address: </label><br/>
						<input type="email" name="email"/><br/>
					<label>First name: </label><br/>
						<input type="text" name="fname"/><br/>
					<label>Last: </label><br/>
						<input type="text" name="lname"/><br/>
					<input type="checkbox" name="agreement" value="accept"/> I have read and understand this agreement<br/><br/>
						<input type="submit" name="submit" value="Submit"/>
						<input type="reset"  value="Clear"/>
				</form>
				
			</div>
			
		</div>
		<div id="ads">
			<img class="img-ads" src="media/ads.gif">
		</div>
	</div>

	<footer>
		<div class="footer-list">
			<ul>
				<li><i>ANIMAL CARE</i></li>
				<li><a href="#">Dogs</a></li>
				<li><a href="#">Cats</a></li>
				<li><a href="#">Reptiles</a></li>
			</ul>
			<ul>
				<li><i>CONTACT INFO</i></li>
				<li><a href="#">Contact Us</a></li>
				<li><a href="#">Feedbacks</a></li>
				<li><a href="#">Gallery</a></li>
			</ul>
			<ul>
				<li><i>PHYSICAL STORE</i></li>
				<li>Location: UE Tech Road,</li>
				<li>Samson Road, Caloocan City</li>
			</ul>
			<ul>
				<li><i>FOLLOW US</i></li>
				<li>MnM Online PetShop - Philippines</li>
				<li>
					<img src="media/footer-fb.png">
				</li>
				<li>
					<img src="media/footer-twitter.png">
				</li>
				<li>
					<img src="media/footer-insta.png">
				</li>
				<li>
					<img src="media/footer-google.png">
				</li>
			</ul>
			<p class="copyright">&copy; 2017 MnM Online PetShop. All Rights Reserved</p>
	</footer>
</body>
</html>