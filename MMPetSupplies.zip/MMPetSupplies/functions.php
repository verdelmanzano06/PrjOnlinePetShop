<?php 
include("includes/dbinfo.inc.php");

function getGallery() {
	global $con;
	
	$get_gall = "SELECT * FROM gallery ORDER BY GALLERY_ID";
	$run_gall = oci_parse($con, $get_gall);
	oci_execute($run_gall);
	
	while($row = oci_fetch_array($run_gall)) {
				$gallery_id = $row['GALLERY_ID'];
				$gallery_img = $row['GALLERY_IMG'];
				$gallery_desc = $row['GALLERY_DESC'];
				
				echo "<div class='col-md-4'>
						<a target='_parent' href='media/gallery/$gallery_img' class='thumbnail'>
						  <img class='img-responsive' style='width:350px; height:230px;' src='media/gallery/$gallery_img' alt='$gallery_desc'>
						</a>
					  </div>";
		} 
	/*
	$rpp = 3;
	
	isset($_GET['page']) ? $page = $_GET['page'] : $page = 0;
	
	if($page >  1){
		$start = ($page * $rpp) - $rpp;
	} else {
		$start = 0;
	
	
	$sql = "SELECT gallery_id, gallery_img, gallery_desc FROM gallery";
	$result_set = oci_parse($con, $sql);
	oci_execute($result_set);
	
	
	while (oci_fetch_array($result_set)) {}
	
	$num_rows = oci_num_rows($result_set);
	
	$total_pages = ceil($num_rows / $rpp);
	
	
	$sql = "SELECT * FROM (SELECT ROWNUM rnum,a.* FROM (SELECT * FROM gallery order by gallery_id asc) a) WHERE rnum BETWEEN $start AND $rpp";
	
	$result_set = oci_parse($con, $sql);
	oci_execute($result_set);

	
	while ($rows = oci_fetch_array($result_set, OCI_ASSOC)) {
		
		$gallery_id = $rows['GALLERY_ID'];
		$gallery_img = $rows['GALLERY_IMG'];
		$gallery_desc = $rows['GALLERY_DESC'];
		
		echo "<div class='col-md-4'>
						<a target='_parent' href='media/gallery/$gallery_img' class='thumbnail'>
						  <img class='img-responsive' style='width:350px; height:230px;' src='media/gallery/$gallery_img' alt='$gallery_desc'>
						</a>
					  </div>";
					  
	}

	echo '<ul class="pagination" style="float: right;">';
		for ($x = 1; $x <= $total_pages; $x++) {
			echo "<li><a href='?page=$x'>$x</a></li> ";
		}
	echo '</ul>';
	
	
	}
	
	
	----------------------------------------------------
	
	
	//define how many results you want per page
	$results_per_page = 3;
	
	
	//find out the number of results stored in database
	$sql= "SELECT * FROM gallery";
	$result = oci_parse($con, $sql);
	oci_execute($result);
	
	while ($row = oci_fetch_array($result)) {
		//Lol
	}
	
	$number_of_results = oci_num_rows($result);
	

	//determine number of total pages available
	$number_of_pages = ceil($number_of_results/$results_per_page);
	
	
	//determine which page number visitor is currently on
	if (!isset($_GET['page'])) {
		$page = 1;
	} else {
		$page = $_GET['page'];
	}
	
	
	//determine the sql LIMIT starting number for the results on the displaying page
	$this_page_first_result = ($page-1) * $results_per_page;
	
	
	//retrieve selected results from database and display them on page
	$sql = "SELECT *
			FROM gallery
			ORDER BY gallery_id
			OFFSET '$this_page_first_result' ROWS FETCH NEXT '$results_per_page' ROWS ONLY";
	$result = oci_parse($con, $sql);
	oci_execute($result);

	while ($row = oci_fetch_array($result)) {
		$gallery_id = $row['GALLERY_ID'];
		$gallery_img = $row['GALLERY_IMG'];
		$gallery_desc = $row['GALLERY_DESC'];
		
		echo "<div class='col-md-4'>
						<a target='_parent' href='media/gallery/$gallery_img' class='thumbnail'>
						  <img class='img-responsive' style='width:350px; height:230px;' src='media/gallery/$gallery_img' alt='$gallery_desc'>
						</a>
					  </div>";
	}
	
	//display the links to the pages
	for ($page=1;$page <= $number_of_pages;$page++) {
		echo '<a href="gallery.php?page=' . $page . '">' . $page . '</a>  ';
	}
		
	*/
	
}

function getCats() {
	global $con;
	$get_cats = "SELECT * FROM categories ORDER BY CATEGORY_ID";
	$run_cats = oci_parse($con, $get_cats);
	oci_execute($run_cats);

	echo "<div class='nav'><li class='label label-danger'><h5><b>CATEGORIES</b></h5></li>";
	echo "<li><a href='shop.php'>All Products</a></li>";
	
		while($row = oci_fetch_array($run_cats)) {
				$category_id = $row['CATEGORY_ID'];
				$category_name = $row['CATEGORY_NAME'];
				
				echo "<li><a href='shop.php?cat=$category_id'>$category_name</a></li>";
		} 

		echo "</div>";
		
		oci_free_statement($run_cats);
		
}

function getAnimals() {
	global $con;
	$get_animals = "SELECT * FROM animals ORDER BY ANIMAL_ID";
	$run_animals = oci_parse($con, $get_animals);
	oci_execute($run_animals);
	
	echo "<div class='nav'><li class='label label-danger'><h5><b>ANIMALS</b></h5></li>";

	while($row = oci_fetch_array($run_animals)) {
				$animal_id = $row['ANIMAL_ID'];
				$animal_name = $row['ANIMAL_NAME'];
				echo "<li><a href='shop.php?anim=$animal_id'>All $animal_name</a></li>";
		} 

	echo "</div>";
		
	oci_free_statement($run_animals);
	
}

function getProds() {
	if (!isset($_GET['cat'])) {
		if (!isset($_GET['anim'])) {
	global $con;

	$get_prod = "SELECT * FROM products";

	$run_prod = oci_parse($con, $get_prod);
	oci_execute($run_prod);
	
	while($row = oci_fetch_array($run_prod)) {
			$prod_id = $row['PROD_ID']; 
			$prod_cat = $row['PROD_CAT']; 
			$prod_animal = $row['PROD_ANIMAL']; 
			$prod_title = $row['PROD_TITLE'];
			$prod_price = $row['PROD_PRICE']; 
			$prod_desc = $row['PROD_DESC'];
			$prod_image = $row['PROD_IMAGE']; 
			$prod_keywords = $row['PROD_KEYWORDS']; 
			
			echo "<div class='col-sm-4'>
							<div class='panel panel-info'>
								<div class='panel-heading'><a href='view_details.php?prod_id=$prod_id'>$prod_title</a></div>
								<div class='panel-body'>
									<a href='view_details.php?prod_id=$prod_id'><img class='img-responsive' src='media/product_images/$prod_image'/></a>
								</div>
								<div class='panel-heading'>
								&#8369 $prod_price.00
									<a style='float:right;' class='btn btn-danger btn-xs' href='shop.php?prod_id=$prod_id'>Add to Cart</a>
								</div>
							</div>
						</div>";
		}
		oci_free_statement($run_prod);
		
}
	}
}

function getCatProds() {
	if (isset($_GET['cat'])) {
		
			$cat_id = $_GET['cat'];
		
	global $con;

	$get_cat_prod = "SELECT * FROM products WHERE prod_cat='$cat_id'";

	$run_cat_prod = oci_parse($con, $get_cat_prod);
	oci_execute($run_cat_prod);
	
	$count_cat = oci_num_rows($run_cat_prod);
	

		while ($row_cat_prod = oci_fetch_array($run_cat_prod)) {
			$prod_id = $row_cat_prod['PROD_ID']; 
			$prod_cat = $row_cat_prod['PROD_CAT']; 
			$prod_animal = $row_cat_prod['PROD_ANIMAL']; 
			$prod_title = $row_cat_prod['PROD_TITLE'];
			$prod_price = $row_cat_prod['PROD_PRICE']; 
			$prod_desc = $row_cat_prod['PROD_DESC'];
			$prod_image = $row_cat_prod['PROD_IMAGE']; 
			$prod_keywords = $row_cat_prod['PROD_KEYWORDS']; 
			
			echo "<div class='col-sm-4'>
							<div class='panel panel-info'>
								<div class='panel-heading'><a href='view_details.php?prod_id=$prod_id'>$prod_title</a></div>
								<div class='panel-body'>
									<a href='view_details.php?prod_id=$prod_id'><img class='img-responsive' src='media/product_images/$prod_image'/></a>
								</div>
								<div class='panel-heading'>P $prod_price
									<a style='float:right;' class='btn btn-danger btn-xs' href='shop.php?add_cart=$prod_id'>Add to Cart</a>
								</div>
							</div>
						</div>";
			}
			oci_free_statement($run_cat_prod);
			
	
	}
}	

	function getAnimProds() {
	if (isset($_GET['anim'])) {
		
			$animal_id = $_GET['anim'];
		
	global $con;

	$get_animal_prod = "SELECT * FROM products WHERE prod_animal='$animal_id'";

	$run_animal_prod = oci_parse($con, $get_animal_prod);
	oci_execute($run_animal_prod);
	
	$count_brand = oci_num_rows($run_animal_prod);
	
	
	
	while ($row_anim_prod = oci_fetch_array($run_animal_prod)) {
			//$prod_brand = $row_brand_prod['product_id'];
			$prod_id = $row_anim_prod['PROD_ID']; 
			$prod_cat = $row_anim_prod['PROD_CAT']; 
			$prod_animal = $row_anim_prod['PROD_ANIMAL']; 
			$prod_title = $row_anim_prod['PROD_TITLE'];
			$prod_price = $row_anim_prod['PROD_PRICE']; 
			$prod_desc = $row_anim_prod['PROD_DESC'];
			$prod_image = $row_anim_prod['PROD_IMAGE']; 
			$prod_keywords = $row_anim_prod['PROD_KEYWORDS']; 

			echo "<div class='col-sm-4'>
							<div class='panel panel-info'>
								<div class='panel-heading'><a href='view_details.php?prod_id=$prod_id'>$prod_title</a></div>
								<div class='panel-body'>
									<a href='view_details.php?prod_id=$prod_id'><img class='img-responsive' src='media/product_images/$prod_image'/></a>
								</div>
								<div class='panel-heading'>P $prod_price
									<a style='float:right;' class='btn btn-danger btn-xs'href='shop.php?add_cart=$prod_id'>Add to Cart</a>
								</div>
							</div>
						</div>";
			}
			oci_free_statement($run_animal_prod);
			
	}	
}
/*
if(isset($_POST["cat"])) {
	$run_query = oci_parse($con, "SELECT * FROM categories ORDER BY category_name");
	oci_execute($run_query);

	echo "<div class='nav'><li class='label label-danger'><h5><b>CATEGORIES</b></h5></li>";
		
	if (oci_num_rows($run_query) >= 0) {
		while($row = oci_fetch_array($run_query)) {
				$category_id = $row[0];
				$category_name = $row[1];
				
				echo "<li><a href='#' class='categ' cid='$category_id'>$category_name</a></li>";
		} 

		echo "</div>";
	}
}

if(isset($_POST["anl"])) {
	$run_query = oci_parse($con, "SELECT * FROM animals ORDER BY animal_name");
	oci_execute($run_query);

	echo "<div class='nav'><li class='label label-danger'><h5><b>ANIMALS</b></h5></li>";
		
	if (oci_num_rows($run_query) >= 0) {
		while($row = oci_fetch_array($run_query)) {
				$animal_id = $row[0];
				$animal_name = $row[1];
				echo "<li><a href='#' class='anim' aid='$animal_id'>$animal_name</a></li>";
		} 

		echo "</div>";
	}
}

if(isset($_POST["get_Supplies"])) {
	$run_query = oci_parse($con, "SELECT * FROM products");
	oci_execute($run_query);
	
	if(oci_num_rows($run_query) >= 0	) {
		while($row = oci_fetch_array($run_query)) {
			$prod_id = $row[0]; 
			$prod_cat = $row[1]; 
			$prod_animal = $row[2]; 
			$prod_title = $row[3];
			$prod_price = $row[4]; 
			$prod_desc = $row[5];
			$prod_image = $row[6]; 
			$prod_keywords = $row[7]; 
			
			echo "	<div class='col-sm-4'>
							<div class='panel panel-info'>
								<div class='panel-heading'>$prod_title</div>
								<div class='panel-body'>
									<img class='img-responsive' src='media/product_images/$prod_image'/>
								</div>
								<div class='panel-heading'>P $prod_price
									<button pid='$prod_id' style='float: right;' id='product' class='btn btn-danger btn-xs'>Add to Cart</button>
								</div>
							</div>
						</div>";
		}
	}
}

if(isset($_POST["get_selected_Category"]) || isset($_POST["get_selected_Animal"]) || isset($_POST["searches"])) {
	if(isset($_POST["get_selected_Category"])) {
		$id = $_POST["category_id"];
		$sql = "SELECT * FROM products WHERE prod_cat = '$id'";
	} else if(isset($_POST["get_selected_Animal"])) {
		$id = $_POST["animal_id"];
		$sql = "SELECT * FROM products WHERE prod_animal = '$id'";
	} else {
		$search_keyword = $_POST["keywords"];
		$sql = "SELECT * FROM products WHERE prod_keywords LIKE '%$search_keyword%'";
	}
	
	$run_query = oci_parse($con, $sql);
	oci_execute($run_query);
	
	
		while($row = oci_fetch_array($run_query)) {
			$prod_id = $row[0]; 
			$prod_cat = $row[1]; 
			$prod_animal = $row[2]; 
			$prod_title = $row[3];
			$prod_price = $row[4]; 
			$prod_desc = $row[5];
			$prod_image = $row[6]; 
			$prod_keywords = $row[7]; 
			
			echo "<div class='col-sm-4'>
							<div class='panel panel-info'>
								<div class='panel-heading'>$prod_title</div>
								<div class='panel-body'>
									<img class='img-responsive' src='media/product_images/$prod_image'/>
								</div>
								<div class='panel-heading'>P $prod_price
									<button pid='$prod_id' style='float: right;' id='supplies' class='btn btn-danger btn-xs'>Add to Cart</button>
								</div>
							</div>
						</div>";
		}
	
}

if(isset($_POST["addToProduct"])) {
	$s_id = $_POST['proId'];
	//$user_id = $_SESSION['cust_id'];
	$sql = "SELECT * FROM cart WHERE s_id = '$s_id' AND cust_id = '$user_id'";
	$run_query = oci_parse($con, $sql);
	oci_execute($run_query);
	oci_fetch_array($run_query);
	$count = oci_num_rows($run_query);
	
	if($count > 0){
		echo "<div class='alert alert-info'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times</a><strong>Product is already added into the cart</strong>
				</div>";
	} else {
		$sql = "SELECT * FROM products WHERE prod_id = '$s_id'";
		$run_query = oci_parse($con, $sql);
		oci_execute($run_query);
		$row = oci_fetch_array($run_query);
			$id = $row[0];
			$prod_name = $row[7];
			$prod_image = $row[5];
			$prod_price = $row[3];
			$qty = 1;
			$ip = "0";
			
		$sql = "INSERT INTO cart VALUES (NULL, '$s_id','$ip','$user_id','$prod_name','$prod_image','$qty','$prod_price','$prod_price')";
		$run_query = oci_parse($con, $sql);
		oci_execute($run_query);
		
		if($run_query) {
			
			echo "<div class='alert alert-success'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times</a><strong>Product is Added</strong>
				</div>";
		} else {
			
		}
		
		
	}
}
*/

?>