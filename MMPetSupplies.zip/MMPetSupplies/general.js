/* $(document).ready(function() {
	category();
	animal();
	supplies();
	function category() {
		$.ajax({
			url : 'functions.php',
			method: 'POST',
			data : {cat:1},
			success : function(data){
				$('#get_category').html(data);
			} 
		})
	}
	
	function animal() {
		$.ajax({
			url : 'functions.php',
			method: 'POST',
			data : {anl:1},
			success : function(data){
				$('#get_animal').html(data);
			} 
		})
	}
	
	function supplies() {
		$.ajax({
			url : 'functions.php',
			method: 'POST',
			data : {get_Supplies:1},
			success : function(data){
				$('#get_supplies').html(data);
			} 
		})
	}
	
	$("body").delegate(".categ","click",function(event) {
		event.preventDefault();
		var cid = $(this).attr('cid');

			$.ajax({
			url : 'functions.php',
			method: 'POST',
			data : {get_selected_Category:1,category_id:cid},
			success : function(data){
				$('#get_supplies').html(data);
			} 
		})
		
	})
	
	$("body").delegate(".anim","click",function(event) {
		event.preventDefault();
		var aid = $(this).attr('aid');

			$.ajax({
			url : 'functions.php',
			method: 'POST',
			data : {get_selected_Animal:1,animal_id:aid},
			success : function(data){
				$('#get_supplies').html(data);
			} 
		})
		
	})
	
	$("#search-button"),click(function(){
		var keyword = $('#searchna').val();
		if(keyword != ""){
				$.ajax({
					url		: 'functions.php',
					method	: 'POST',
					data	: {searches:1,keyword:keyword},
					success	: function(data){
						$('#get_supplies').html(data);
					}
				})
		}
	})
	
	$("body").delegate("#supplies","click",function(event){
	event.preventDefault();
	var s_id = $(this).attr('sid');
	$.ajax({
		url		:	"functions.php",
		method	:	"POST",
		data	:	{addToProduct:1,proId:s_id},
		success	:	function(data) {
			$('#product_msg').html(data);
			}
		})
	})

	
	
	
	
})

*/