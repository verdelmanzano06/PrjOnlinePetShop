<?php 
	session_start();
?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">Add Product</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-10">
								<form method="post" class="form-horizontal" enctype="multipart/form-data">
										<p>Product Category: <select name="product_cat" required>
											<option disabled selected value>Select a Category</option>
											<?php 
												$get_cats = "SELECT * FROM categories ORDER BY category_id";
												$run_cats = oci_parse($con, $get_cats);
												oci_execute($run_cats);

												while ($row_cats = oci_fetch_array($run_cats)) {
													$cat_id = $row_cats['CATEGORY_ID'];
													$cat_title = $row_cats['CATEGORY_NAME'];
													echo "<option value='$cat_id'>$cat_title</option>";
												}
							 				?>
										</select></p>
					
					
										<p>Animal Category: <select name="product_anim" required>
											<option disabled selected value>Select a Type</option>
											<?php 
												$get_anim = "SELECT * FROM animals ORDER BY animal_id";
												$run_anim = oci_parse($con, $get_anim);
												oci_execute($run_anim);

												while ($row_brands = oci_fetch_array($run_anim)) {
													$animal_id = $row_brands['ANIMAL_ID'];
													$animal_name = $row_brands['ANIMAL_NAME'];
													echo "<option value='$animal_id'>$animal_name</option>";
												}
											?>
										</select></p>
										
						
										<p>Product Title: <input type="text" name="product_title" /></p>
						
										<p>Product Price: <input type="text" name="product_price" /></p>
						
										<p>Product Details:</p> <textarea name="product_desc" cols="25" rows="10"></textarea>
						
										<p>Product Image: <input type="file" name="product_image"/></p>
										
										<p>Product Keywords: <input type="text" name="product_keywords" /></p>
										<hr/>
										<p><input class="btn btn-success" type="submit" name="submit_product" value="Add Product"/></p>
									
										
								</form>
								
								<?php 
								
									if (isset($_POST['submit_product'])) {
										
										$sql = "INSERT INTO products (PROD_CAT, PROD_ANIMAL, PROD_TITLE, PROD_PRICE, PROD_DESC, PROD_IMAGE, PROD_KEYWORDS) VALUES (:p_cat_bv, :p_anim_bv, :p_title_bv, :p_price_bv, :p_desc_bv, :p_img_bv, :p_key_bv)";
										
										$run_query = oci_parse($con, $sql);
										
										//Get the image from user fields
										$product_image = $_FILES['product_image']['name'];
										$product_image_tmp = $_FILES['product_image']['tmp_name'];

										//Uploaded file destination
										move_uploaded_file($product_image_tmp, '../media/product_images/$product_images');
										
										
										oci_bind_by_name($run_query, ":p_cat_bv", $_POST['product_cat']);
										oci_bind_by_name($run_query, ":p_anim_bv", $_POST['product_anim']);
										oci_bind_by_name($run_query, ":p_title_bv", $_POST['product_title']);
										oci_bind_by_name($run_query, ":p_price_bv", $_POST['product_price']);
										oci_bind_by_name($run_query, ":p_desc_bv", $_POST['product_desc']);
										oci_bind_by_name($run_query, ":p_img_bv", $product_images);
										oci_bind_by_name($run_query, ":p_key_bv", $_POST['product_keywords']);
										
										oci_execute($run_query);
										echo "<script>alert('Product has been added to shop!')</script>";
										
										oci_free_statement($run_query);
										oci_close($con);
	
									}
								
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		